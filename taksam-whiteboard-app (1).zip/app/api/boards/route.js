import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { getPool, ensureSchema, parseDoc } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/boards — list boards (lightweight: no full doc except a preview)
export async function GET() {
  try {
    await ensureSchema();
    const [rows] = await getPool().query(
      "SELECT id, title, template_name, accent, doc, updated_at FROM boards ORDER BY updated_at DESC LIMIT 200"
    );
    const boards = rows.map((r) => ({
      id: r.id,
      title: r.title,
      templateName: r.template_name,
      accent: r.accent,
      updatedAt: new Date(r.updated_at).getTime(),
      doc: parseDoc(r.doc), // included so the dashboard can render live thumbnails
    }));
    return NextResponse.json({ boards });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

// POST /api/boards — create a board  { title, templateName, accent, doc }
export async function POST(request) {
  try {
    await ensureSchema();
    const body = await request.json();
    // Allow a caller-supplied id (used by "undo delete" to restore the same board);
    // otherwise generate one. Only accept a safe [a-z0-9] id up to 32 chars.
    const id = (typeof body.id === "string" && /^[a-z0-9]{1,32}$/i.test(body.id))
      ? body.id
      : randomUUID().replace(/-/g, "").slice(0, 32);
    const doc = body.doc || { title: body.title || "Untitled Whiteboard", elements: [], camera: { x: 0, y: 0, zoom: 1 } };
    const title = (body.title || doc.title || "Untitled Whiteboard").slice(0, 255);
    await getPool().query(
      "INSERT INTO boards (id, title, template_name, accent, doc) VALUES (?, ?, ?, ?, ?)",
      [id, title, body.templateName || null, body.accent || null, JSON.stringify(doc)]
    );
    return NextResponse.json({ id, title });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
