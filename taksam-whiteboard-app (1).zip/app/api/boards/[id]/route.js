import { NextResponse } from "next/server";
import { getPool, ensureSchema, parseDoc } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/boards/:id — full board incl. document
export async function GET(_request, context) {
  try {
    await ensureSchema();
    const { id } = await context.params;
    const [rows] = await getPool().query(
      "SELECT id, title, template_name, accent, doc, updated_at FROM boards WHERE id = ? LIMIT 1",
      [id]
    );
    if (!rows.length) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const r = rows[0];
    return NextResponse.json({
      board: {
        id: r.id, title: r.title, templateName: r.template_name, accent: r.accent,
        updatedAt: new Date(r.updated_at).getTime(), doc: parseDoc(r.doc),
      },
    });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

// PUT /api/boards/:id — save board  { title, doc }
export async function PUT(request, context) {
  try {
    await ensureSchema();
    const { id } = await context.params;
    const body = await request.json();
    const doc = body.doc;
    if (!doc) return NextResponse.json({ error: "Missing doc" }, { status: 400 });
    const title = (body.title || doc.title || "Untitled Whiteboard").slice(0, 255);
    const [res] = await getPool().query(
      "UPDATE boards SET title = ?, doc = ? WHERE id = ?",
      [title, JSON.stringify(doc), id]
    );
    if (!res.affectedRows) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

// DELETE /api/boards/:id
export async function DELETE(_request, context) {
  try {
    await ensureSchema();
    const { id } = await context.params;
    await getPool().query("DELETE FROM boards WHERE id = ?", [id]);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
