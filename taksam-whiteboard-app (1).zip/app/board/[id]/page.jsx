import WhiteboardEditor from "@/components/WhiteboardEditor";

export default async function Page({ params }) {
  const { id } = await params;
  return <WhiteboardEditor boardId={id} />;
}
