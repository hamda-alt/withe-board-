-- TaksamAI Whiteboard — MySQL schema
-- Works on MySQL 5.7+ and MySQL 8 (JSON column type required).

CREATE DATABASE IF NOT EXISTS taksam_whiteboard
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE taksam_whiteboard;

CREATE TABLE IF NOT EXISTS boards (
  id            VARCHAR(40)  NOT NULL,
  title         VARCHAR(255) NOT NULL DEFAULT 'Untitled Whiteboard',
  template_name VARCHAR(120) NULL,
  accent        VARCHAR(20)  NULL,
  doc           JSON         NOT NULL,             -- {title, elements[], camera}
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
                             ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_boards_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
