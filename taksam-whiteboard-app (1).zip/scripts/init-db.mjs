// Initialize the MySQL database + `boards` table.
// Usage: node scripts/init-db.mjs   (reads .env / .env.local or shell env)
import mysql from "mysql2/promise";
import fs from "node:fs";
import path from "node:path";

// minimal .env loader (no dependency)
for (const f of [".env.local", ".env"]) {
  const p = path.join(process.cwd(), f);
  if (!fs.existsSync(p)) continue;
  for (const line of fs.readFileSync(p, "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}

const dbName = process.env.DB_NAME || "taksam_whiteboard";
const base = process.env.DATABASE_URL
  ? process.env.DATABASE_URL
  : {
      host: process.env.DB_HOST || "127.0.0.1",
      port: Number(process.env.DB_PORT || 3306),
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      multipleStatements: true,
    };

const SCHEMA = `
CREATE TABLE IF NOT EXISTS boards (
  id            VARCHAR(40)  NOT NULL,
  title         VARCHAR(255) NOT NULL DEFAULT 'Untitled Whiteboard',
  template_name VARCHAR(120) NULL,
  accent        VARCHAR(20)  NULL,
  doc           JSON         NOT NULL,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_boards_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
`;

(async () => {
  const conn = await mysql.createConnection(base);
  if (typeof base === "object") {
    await conn.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
    await conn.changeUser({ database: dbName });
  }
  await conn.query(SCHEMA);
  console.log(`✓ Database "${dbName}" ready with table "boards".`);
  await conn.end();
})().catch((e) => { console.error("DB init failed:", e.message); process.exit(1); });
