"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import WB from "@/lib/whiteboard-engine.js";

const TEMPLATES = WB.TEMPLATES;
const FAVS_KEY = "taksam_favs_v1";
const VIEWS_KEY = "taksam_views_v1";

function timeAgo(t) {
  if (!t) return "—";
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return Math.floor(s / 86400) + "d ago";
}
function bounds(e) {
  if (e.type === "connector") return { x: Math.min(e.x1, e.x2), y: Math.min(e.y1, e.y2), w: Math.abs(e.x2 - e.x1) || 1, h: Math.abs(e.y2 - e.y1) || 1 };
  if (e.type === "draw") { const p = e.points || [[0, 0]]; let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity; p.forEach((q) => { a = Math.min(a, q[0]); b = Math.min(b, q[1]); c = Math.max(c, q[0]); d = Math.max(d, q[1]); }); return { x: a, y: b, w: c - a || 1, h: d - b || 1 }; }
  return { x: e.x, y: e.y, w: e.w, h: e.h };
}
function thumbSVG(doc) {
  const els = (doc && doc.elements) || [];
  if (!els.length) return `<div class="tk-thumb-empty">▦</div>`;
  let minx = Infinity, miny = Infinity, maxx = -Infinity, maxy = -Infinity;
  els.forEach((e) => { const b = bounds(e); minx = Math.min(minx, b.x); miny = Math.min(miny, b.y); maxx = Math.max(maxx, b.x + b.w); maxy = Math.max(maxy, b.y + b.h); });
  const w = Math.max(1, maxx - minx), h = Math.max(1, maxy - miny);
  let inner = "";
  els.forEach((e) => {
    if (e.type === "connector") { inner += `<line x1="${e.x1}" y1="${e.y1}" x2="${e.x2}" y2="${e.y2}" stroke="${e.stroke}" stroke-width="${(e.strokeWidth || 2) * 1.5}"/>`; return; }
    if (e.type === "draw") { const p = e.points || []; if (p.length) inner += `<polyline points="${p.map((q) => q.join(",")).join(" ")}" fill="none" stroke="${e.stroke}" stroke-width="${e.strokeWidth || 3}"/>`; return; }
    const fill = e.type === "note" ? e.fill : (e.fill && e.fill !== "none" ? e.fill : "none");
    if (e.type === "ellipse") inner += `<ellipse cx="${e.x + e.w / 2}" cy="${e.y + e.h / 2}" rx="${e.w / 2}" ry="${e.h / 2}" fill="${fill}" stroke="${e.stroke}" stroke-width="${e.strokeWidth || 2}"/>`;
    else { const rx = (e.type === "roundrect" || e.type === "note" || e.type === "task") ? 8 : 0; inner += `<rect x="${e.x}" y="${e.y}" width="${e.w}" height="${e.h}" rx="${rx}" fill="${e.type === "task" ? "#1E1E22" : fill}" stroke="${e.stroke}" stroke-width="${e.strokeWidth || 2}"/>`; }
  });
  return `<svg viewBox="${minx - 10} ${miny - 10} ${w + 20} ${h + 20}" preserveAspectRatio="xMidYMid meet" class="tk-thumb-svg">${inner}</svg>`;
}
function Star({ on }) {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill={on ? "#F6C445" : "none"} stroke={on ? "#F6C445" : "currentColor"} strokeWidth="2">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </svg>
  );
}

export default function Dashboard() {
  const router = useRouter();
  const [boards, setBoards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [view, setView] = useState("all");
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState("updated");
  const [layout, setLayout] = useState("grid");
  const [navCollapsed, setNavCollapsed] = useState(false);
  const [theme, setTheme] = useState("dark");
  const [favs, setFavs] = useState(() => new Set());
  const [views, setViews] = useState({});
  const [menu, setMenu] = useState(null);
  const [renamingId, setRenamingId] = useState(null);
  const [toast, setToast] = useState(null);
  const searchRef = useRef(null);
  const toastTimer = useRef(null);

  useEffect(() => {
    const t = localStorage.getItem("taksam_theme") || "dark";
    setTheme(t); document.documentElement.dataset.theme = t;
    try { setFavs(new Set(JSON.parse(localStorage.getItem(FAVS_KEY) || "[]"))); } catch {}
    try { setViews(JSON.parse(localStorage.getItem(VIEWS_KEY) || "{}")); } catch {}
  }, []);

  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    const id = setTimeout(() => document.addEventListener("click", close), 0);
    return () => { clearTimeout(id); document.removeEventListener("click", close); };
  }, [menu]);

  const showToast = useCallback((msg, action) => {
    setToast({ msg, actionLabel: action?.label, actionFn: action?.fn });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), action ? 5000 : 2200);
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch("/api/boards");
      if (!r.ok) throw new Error((await r.json()).error || "Failed to load boards");
      setBoards((await r.json()).boards || []); setError(null);
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);

  const persistFavs = (n) => { try { localStorage.setItem(FAVS_KEY, JSON.stringify([...n])); } catch {} };
  const persistViews = (n) => { try { localStorage.setItem(VIEWS_KEY, JSON.stringify(n)); } catch {} };

  async function createBoard(tpl) {
    try {
      const doc = tpl.build();
      const r = await fetch("/api/boards", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: doc.title || tpl.name, templateName: tpl.name, accent: tpl.accent, doc }) });
      if (!r.ok) throw new Error((await r.json()).error || "Create failed");
      openBoard((await r.json()).id);
    } catch (e) { showToast("Could not create board: " + e.message); }
  }
  async function duplicateBoard(b) {
    try {
      const doc = JSON.parse(JSON.stringify(b.doc || {}));
      doc.title = (b.title || "Untitled") + " (copy)";
      const r = await fetch("/api/boards", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: doc.title, templateName: b.templateName, accent: b.accent, doc }) });
      if (!r.ok) throw new Error("Duplicate failed");
      showToast("Duplicated ✓"); refresh();
    } catch (e) { showToast(e.message); }
  }
  async function renameBoard(id, title) {
    const b = boards.find((x) => x.id === id); if (!b) return;
    const t = (title || "").trim() || "Untitled";
    setBoards((arr) => arr.map((x) => (x.id === id ? { ...x, title: t } : x)));
    try { await fetch(`/api/boards/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: t, doc: { ...(b.doc || {}), title: t } }) }); }
    catch { showToast("Rename failed"); refresh(); }
  }
  async function deleteBoard(b) {
    setBoards((arr) => arr.filter((x) => x.id !== b.id));
    try { await fetch(`/api/boards/${b.id}`, { method: "DELETE" }); } catch {}
    showToast("Moved to trash", {
      label: "Undo",
      fn: async () => {
        try { await fetch("/api/boards", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: b.id, title: b.title, templateName: b.templateName, accent: b.accent, doc: b.doc }) }); } catch {}
        refresh();
      },
    });
  }
  function toggleFav(id) {
    setFavs((prev) => { const n = new Set(prev); const on = n.has(id); on ? n.delete(id) : n.add(id); persistFavs(n); if (!on) showToast("Added to Favorites ★"); return n; });
  }
  function copyLink(id) {
    const url = `${location.origin}/board/${id}`;
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(url).then(() => showToast("🔗 Link copied!"), () => prompt("Copy link:", url));
    else prompt("Copy link:", url);
  }
  function openBoard(id) {
    const next = { ...views, [id]: Date.now() };
    setViews(next); persistViews(next);
    router.push(`/board/${id}`);
  }
  function toggleTheme() {
    const t = theme === "dark" ? "light" : "dark";
    setTheme(t); document.documentElement.dataset.theme = t; localStorage.setItem("taksam_theme", t);
  }
  function cardAction(act, b) {
    setMenu(null);
    if (act === "fav") toggleFav(b.id);
    else if (act === "link") copyLink(b.id);
    else if (act === "rename") { setRenamingId(b.id); setTimeout(() => { const el = document.querySelector("[data-rename]"); if (el) { el.focus(); el.select(); } }, 20); }
    else if (act === "dup") duplicateBoard(b);
    else if (act === "del") deleteBoard(b);
  }

  const q = query.toLowerCase();
  let myBoards = boards.filter((b) => !q || (b.title || "").toLowerCase().includes(q));
  const cmp = {
    updated: (x, y) => y.updatedAt - x.updatedAt,
    created: (x, y) => (y.createdAt || y.updatedAt) - (x.createdAt || x.updatedAt),
    viewed: (x, y) => (views[y.id] || 0) - (views[x.id] || 0),
    name: (x, y) => (x.title || "").localeCompare(y.title || ""),
  }[sortBy];
  myBoards = myBoards.slice().sort(cmp).sort((x, y) => (favs.has(y.id) ? 1 : 0) - (favs.has(x.id) ? 1 : 0));
  const favBoards = boards.filter((b) => favs.has(b.id));
  const act = (b) => Math.max(b.updatedAt || 0, views[b.id] || 0);   // recents = created/duplicated/edited/opened
  const recents = boards.slice().sort((a, b) => act(b) - act(a)).slice(0, 6);
  const sortLabel = { updated: "Last updated", created: "Date created", viewed: "Date viewed", name: "Name (A–Z)" }[sortBy];

  const TitleCell = ({ b, cls }) => renamingId === b.id
    ? <input className="tk-rename-input" data-rename={b.id} defaultValue={b.title}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => { e.stopPropagation(); if (e.key === "Enter") { renameBoard(b.id, e.currentTarget.value); setRenamingId(null); } if (e.key === "Escape") setRenamingId(null); }}
        onBlur={(e) => { renameBoard(b.id, e.currentTarget.value); setRenamingId(null); }} />
    : <div className={cls} title={b.title}>{b.title || "Untitled"}</div>;

  const CardMenu = ({ b }) => (
    <div className="tk-cardmenu-wrap" onClick={(e) => e.stopPropagation()}>
      <button className="tk-cardmenu-btn" title="More" onClick={(e) => { e.stopPropagation(); setMenu((m) => (m === "card:" + b.id ? null : "card:" + b.id)); }}>⋯</button>
      <div className={"tk-cardmenu" + (menu === "card:" + b.id ? " open" : "")}>
        <button className="tk-cm-item" onClick={() => cardAction("fav", b)}><Star on={favs.has(b.id)} /> {favs.has(b.id) ? "Remove from Favorites" : "Favorite"}</button>
        <button className="tk-cm-item" onClick={() => cardAction("link", b)}>🔗 Copy link</button>
        <button className="tk-cm-item" onClick={() => cardAction("rename", b)}>✎ Rename</button>
        <button className="tk-cm-item" onClick={() => cardAction("dup", b)}>⧉ Duplicate</button>
        <div className="tk-cm-sep" />
        <button className="tk-cm-item danger" onClick={() => cardAction("del", b)}>🗑 Delete</button>
      </div>
    </div>
  );

  const HeaderBar = ({ title }) => (
    <div className="tk-my-head">
      <h1>{title}</h1>
      <div className="tk-menu-wrap" onClick={(e) => e.stopPropagation()}>
        <button className="tk-new" onClick={() => setMenu((m) => (m === "new" ? null : "new"))}>New Whiteboard <i>▾</i></button>
        <div className={"tk-menu tk-newmenu" + (menu === "new" ? " open" : "")}>
          {TEMPLATES.map((t) => (
            <button key={t.id} className="tk-menu-item" onClick={() => createBoard(t)}><span className="tk-menu-ic" style={{ color: t.accent }}>{t.icon}</span>{t.name}</button>
          ))}
        </div>
      </div>
    </div>
  );

  const TemplatesStrip = () => (
    <>
      <div className="tk-strip-label">Templates</div>
      <div className="tk-tpl-strip">
        {TEMPLATES.slice(0, 3).map((t) => (
          <button key={t.id} className="tk-tpl-mini" onClick={() => createBoard(t)}>
            <div className="tk-tpl-ic sm" style={{ "--a": t.accent }}><span>{t.icon}</span></div>
            <div className="tk-tpl-mini-txt"><div className="tk-tpl-name">{t.name}</div><div className="tk-tpl-desc">{t.desc}</div></div>
          </button>
        ))}
      </div>
    </>
  );

  const TplCard = (t) => (
    <button key={t.id} className="tk-tpl" onClick={() => createBoard(t)}>
      <div className="tk-tpl-ic" style={{ "--a": t.accent }}><span>{t.icon}</span></div>
      <div className="tk-tpl-name">{t.name}</div>
      <div className="tk-tpl-desc">{t.desc}</div>
    </button>
  );
  // Empty first-open state — mirrors ClickUp's "Choose a Whiteboard template":
  // a clean, centred gallery of quick-start cards (no header, categories or search).
  const GALLERY_IDS = ["org", "action", "journey", "flow", "rca", "blank"];
  const BigGallery = () => {
    const cards = GALLERY_IDS.map((id) => TEMPLATES.find((t) => t.id === id)).filter(Boolean);
    return (
      <div className="tk-gallery">
        <div className="tk-all-head">
          <h1>Choose a Whiteboard template</h1>
          <p>Create Whiteboards to map out project plans, brainstorm feature concepts, or help remote co-workers work better together!</p>
        </div>
        <div className="tk-tpl-grid">{cards.map(TplCard)}</div>
      </div>
    );
  };

  const BoardList = () => (
    <>
      <div className="tk-toolbar">
        <div className="tk-menu-wrap" onClick={(e) => e.stopPropagation()}>
          <button className="tk-tool-btn" onClick={() => setMenu((m) => (m === "sort" ? null : "sort"))}>↕ Sort: <b>{sortLabel}</b> <i>▾</i></button>
          <div className={"tk-menu tk-sortmenu" + (menu === "sort" ? " open" : "")}>
            <button className="tk-menu-item" onClick={() => { setSortBy("updated"); setMenu(null); }}>Last updated</button>
            <button className="tk-menu-item" onClick={() => { setSortBy("created"); setMenu(null); }}>Date created</button>
            <button className="tk-menu-item" onClick={() => { setSortBy("viewed"); setMenu(null); }}>Date viewed</button>
            <button className="tk-menu-item" onClick={() => { setSortBy("name"); setMenu(null); }}>Name (A–Z)</button>
          </div>
        </div>
        <div className="tk-toolbar-r">
          <div className="tk-toolsearch"><span aria-hidden>⌕</span><input ref={searchRef} placeholder="Search" value={query} onChange={(e) => setQuery(e.target.value)} /></div>
          <div className="tk-viewtoggle">
            <button className={layout === "list" ? "on" : ""} onClick={() => setLayout("list")} title="List view">☰</button>
            <button className={layout === "grid" ? "on" : ""} onClick={() => setLayout("grid")} title="Grid view">▦</button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="tk-empty"><div className="tk-empty-ic">⏳</div><div className="tk-empty-t">Loading…</div></div>
      ) : error ? (
        <div className="tk-empty">
          <div className="tk-empty-ic">⚠️</div>
          <div className="tk-empty-t">Couldn’t reach the database</div>
          <div className="tk-empty-s">{error}. Check your MySQL settings in <code>.env</code>, then reload.</div>
        </div>
      ) : myBoards.length === 0 ? (
        <div className="tk-empty">
          <div className="tk-empty-ic">▦</div>
          <div className="tk-empty-t">{query ? "No whiteboards match your search." : "No Whiteboards found"}</div>
          {!query && <>
            <div className="tk-empty-s">Create Whiteboards to map out project plans, brainstorm feature concepts, or help remote co-workers work better together!</div>
            <button className="tk-new" onClick={() => createBoard(TEMPLATES.find((t) => t.id === "blank"))}>New Whiteboard</button>
          </>}
        </div>
      ) : layout === "grid" ? (
        <div className="tk-board-grid">
          {myBoards.map((b) => (
            <div key={b.id} className="tk-board" onClick={() => openBoard(b.id)}>
              <div className="tk-board-thumb" style={{ "--a": b.accent || "#C9A54E" }} dangerouslySetInnerHTML={{ __html: thumbSVG(b.doc) }} />
              <div className="tk-board-meta"><TitleCell b={b} cls="tk-board-title" /><div className="tk-board-sub">Edited {timeAgo(b.updatedAt)}</div></div>
              <button className={"tk-star" + (favs.has(b.id) ? " on" : "")} onClick={(e) => { e.stopPropagation(); toggleFav(b.id); }} title="Favorite"><Star on={favs.has(b.id)} /></button>
              <CardMenu b={b} />
            </div>
          ))}
        </div>
      ) : (
        <div className="tk-board-list">
          <div className="tk-list-head"><span className="lh-name">Name</span><span>Location</span><span>Date updated</span><span>Date created</span><span>Date viewed</span><span /></div>
          {myBoards.map((b) => (
            <div key={b.id} className="tk-row" onClick={() => openBoard(b.id)}>
              <div className="tk-row-thumb" style={{ "--a": b.accent || "#C9A54E" }} dangerouslySetInnerHTML={{ __html: thumbSVG(b.doc) }} />
              <div className="tk-row-name">
                <TitleCell b={b} cls="tk-row-title" />
                <span className="tk-row-actions" onClick={(e) => e.stopPropagation()}>
                  <button onClick={() => copyLink(b.id)} title="Copy link">🔗</button>
                  <button className={favs.has(b.id) ? "on" : ""} onClick={() => toggleFav(b.id)} title="Favorite"><Star on={favs.has(b.id)} /></button>
                  <button onClick={() => cardAction("rename", b)} title="Rename">✎</button>
                </span>
              </div>
              <div className="tk-row-c">My Whiteboards</div>
              <div className="tk-row-c">{timeAgo(b.updatedAt)}</div>
              <div className="tk-row-c">{timeAgo(b.createdAt)}</div>
              <div className="tk-row-c">{timeAgo(views[b.id])}</div>
              <CardMenu b={b} />
            </div>
          ))}
        </div>
      )}
    </>
  );

  const NavList = ({ items }) => (
    <div className="tk-fav-list">
      {items.map((b) => (
        <button key={b.id} className="tk-fav-item" onClick={() => openBoard(b.id)}><span className="tk-fav-dot" style={{ background: b.accent || "#C9A54E" }} /><span className="tk-fav-name">{b.title}</span></button>
      ))}
    </div>
  );

  return (
    <div className="tk-shell">
      <div className="tk-topbar">
        <button className="tk-ws" title="Workspace">◈ TaksamAI <span className="tk-ws-dim">Workspace</span> <i>▾</i></button>
        <div className="tk-arrows"><button title="Back" disabled>‹</button><button title="Forward" disabled>›</button></div>
        <button className="tk-topsearch" onClick={() => { setView("my"); setTimeout(() => searchRef.current?.focus(), 0); }}>
          <span aria-hidden>⌕</span><span className="tk-topsearch-ph">{query || "Search"}</span><kbd>Ctrl J</kbd>
        </button>
        <span className="tk-aichats">AI Chats ✦</span>
        <div className="tk-top-icons"><button className="tk-tic" onClick={toggleTheme} title="Toggle theme">{theme === "dark" ? "☾" : "☀"}</button><span className="tk-avatar">H</span></div>
      </div>

      <div className="tk-body">
        <aside className="tk-rail">
          <button className="tk-rail-ic" title="Home">⌂</button>
          <button className="tk-rail-ic active" title="Whiteboards">▦</button>
          <button className="tk-rail-ic" title="Docs">▤</button>
          <button className="tk-rail-ic" title="Dashboards">▥</button>
          <button className="tk-rail-ic" title="Tasks">☑</button>
          <button className="tk-rail-ic" title="Chat">💬</button>
          <div className="tk-rail-sp" />
          <button className="tk-rail-ic" title="Apps">▦</button>
        </aside>

        <nav className={"tk-nav" + (navCollapsed ? " is-collapsed" : "")}>
          <div className="tk-nav-head"><span>Whiteboards</span>
            <span className="tk-nav-head-btns">
              <button onClick={() => setNavCollapsed(true)} title="Collapse">«</button>
              <button onClick={() => { setView("my"); setMenu("new"); }} title="New whiteboard">＋</button>
            </span>
          </div>
          <button className={"tk-nav-item" + (view === "all" ? " active" : "")} onClick={() => setView("all")}><span>▦</span> All Whiteboards</button>
          <button className={"tk-nav-item" + (view === "my" ? " active" : "")} onClick={() => setView("my")}><span>👤</span> My Whiteboards <b className="tk-nav-count">{boards.length}</b></button>
          <div className="tk-nav-sub">Favorites</div>
          {favBoards.length ? <NavList items={favBoards} /> : <div className="tk-fav-empty"><div className="tk-fav-star">★</div><div>Star a Whiteboard to see it here</div></div>}
          {recents.length > 0 && <><div className="tk-nav-sub">Recents</div><NavList items={recents} /></>}
        </nav>

        <main className="tk-main">
          {view === "all" && boards.length === 0 && !loading && !error ? (
            <BigGallery />
          ) : view === "all" ? (
            <div className="tk-my">
              <HeaderBar title="All Whiteboards" />
              <TemplatesStrip />
              <BoardList />
            </div>
          ) : (
            <div className="tk-my">
              <HeaderBar title="My Whiteboards" />
              <BoardList />
            </div>
          )}
        </main>
      </div>

      {toast && (
        <div className="tk-toast show">
          <span>{toast.msg}</span>
          {toast.actionLabel && <button className="tk-toast-btn" onClick={() => { toast.actionFn?.(); setToast(null); }}>{toast.actionLabel}</button>}
        </div>
      )}
    </div>
  );
}
