"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import WB from "@/lib/whiteboard-engine.js";

export default function WhiteboardEditor({ boardId }) {
  const router = useRouter();
  const hostRef = useRef(null);
  const engineRef = useRef(null);
  const [status, setStatus] = useState("loading"); // loading | ready | notfound | error
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function boot() {
      let board;
      try {
        const r = await fetch(`/api/boards/${boardId}`);
        if (r.status === 404) { if (!cancelled) setStatus("notfound"); return; }
        if (!r.ok) throw new Error((await r.json()).error || "Failed to load board");
        board = (await r.json()).board;
      } catch (e) {
        if (!cancelled) { setErrorMsg(e.message); setStatus("error"); }
        return;
      }
      if (cancelled || !hostRef.current) return;

      const theme = (typeof localStorage !== "undefined" && localStorage.getItem("taksam_theme")) || "dark";

      const save = async (doc) => {
        try {
          await fetch(`/api/boards/${boardId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title: doc.title, doc }),
          });
        } catch (e) { /* transient — the engine will call again on the next change */ }
      };

      engineRef.current = WB.createWhiteboard(hostRef.current, {
        initialDoc: board.doc,
        theme,
        onChange: save,
        onThemeChange: (t) => { try { localStorage.setItem("taksam_theme", t); } catch {} },
        onBack: () => router.push("/"),
        onShare: () => {
          const url = `${location.origin}/board/${boardId}`;
          if (navigator.clipboard?.writeText) navigator.clipboard.writeText(url).catch(() => prompt("Copy this link:", url));
          else prompt("Copy this link:", url);
        },
      });
      if (!cancelled) setStatus("ready");
    }

    boot();
    return () => {
      cancelled = true;
      if (engineRef.current) { engineRef.current.destroy(); engineRef.current = null; }
    };
  }, [boardId, router]);

  return (
    <>
      <div ref={hostRef} className="tk-editor-host" />
      {status === "loading" && (
        <div className="tk-center"><div className="tk-spinner" /><div>Loading whiteboard…</div></div>
      )}
      {status === "notfound" && (
        <div className="tk-center">
          <div style={{ fontSize: 34 }}>🔍</div>
          <div style={{ fontWeight: 700, fontSize: 18 }}>Board not found</div>
          <div>It may have been deleted.</div>
          <button className="tk-new" onClick={() => router.push("/")}>← Back to boards</button>
        </div>
      )}
      {status === "error" && (
        <div className="tk-center">
          <div style={{ fontSize: 34 }}>⚠️</div>
          <div style={{ fontWeight: 700, fontSize: 18 }}>Couldn’t open this board</div>
          <div style={{ maxWidth: 420, textAlign: "center" }}>{errorMsg}</div>
          <button className="tk-new" onClick={() => router.push("/")}>← Back to boards</button>
        </div>
      )}
    </>
  );
}
